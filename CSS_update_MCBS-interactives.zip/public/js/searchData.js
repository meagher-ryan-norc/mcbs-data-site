const searchArr = [
  {
    "title":"Preventive Behaviors",
    "desc":"Explore how Medicare beneficiaries changed their health behaviors during the COVID-19 pandemic.",
    "keywords":"Preventive, Preventative, Face mask, Mask, Quarantine, Social distancing, Social distance, Isolation, Guidance, Guidelines, Safety, Supplies, Provider, Doctor, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Behavior, Medicare Advantage, Pandemic, Dually eligible",
    "url":"/covid-data/preventive/"
  },
  {
    "title":"Forgone Care",
    "desc":"Examine how Medicare beneficiaries put their health care on hold during the COVID-19 pandemic and investigate the types of forgone care.",
    "keywords":"Forgone, Foregone, Delayed, Delay, Postponed, Postpone, Deferred, Defer, Dental, Vision, Screening, Check-up, Check up, Surgery, Procedure, Medication, Medicine, Medical care, Health care, Appointment, Utilization, Access, Access to care, Availability, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Pandemic, Dually eligible",
    "url":"/covid-data/forgone/"
  },
  {
    "title":"Impact on Daily Life",
    "desc":"Learn about how the COVID-19 pandemic affected the everyday lives of Medicare beneficiaries.",
    "keywords":"Face mask, Mask, Medication, Medicine, Medical care, Health care, Access, Access to care, Availability, Needs, Necessities, Financial security, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Appointment, Medicare Advantage, Pandemic, Dually eligible",
    "url":"/covid-data/daily/"
  },
  {
    "title":"Impact on Well-Being",
    "desc":"Explore how the COVID-19 pandemic affected the well-being of Medicare beneficiaries.",
    "keywords":"Isolation, Financial security, Wellness, Mental health, Behavioral health, Emotional, Anxiety, Social support, Social support network, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Pandemic, Dually eligible",
    "url":"/covid-data/well-being/"
  },
  {
    "title":"Availability of Telemedicine",
    "desc":"Examine differences in the availability of health care through telephone or video appointments during the COVID-19 pandemic for Medicare beneficiaries.",
    "keywords":"Medical care, Health care, Appointment, Access, Access to care, Availability, Telehealth, Virtual, Digital, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Medicine, Medication, Utilization, Pandemic, Dually eligible",
    "url":"/covid-data/telemedicine/"
  },
  {
    "title":"Information about COVID-19",
    "desc":"Investigate the different sources Medicare beneficiaries relied on for information about COVID-19.",
    "keywords":"Guidance, Guidelines, Provider, Doctor, Social support, Social support network, News, Internet, Social media, Government, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Medicare Advantage, Pandemic, Dually eligible",
    "url":"/covid-data/information/"
  },
  {
    "title":"COVID-19 Vaccines",
    "desc":"Examine how COVID-19 vaccination uptake and attitudes towards getting vaccinated varied across Medicare beneficiaries.",
    "keywords":"Safety, Medical care, Health care, Appointment, Government, Shot, Dose, Side effect, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Preventive, Preventative, Pandemic, Dually eligible",
    "url":"/covid-data/vaccines/"
  },
  {
    "title":"Perceptions of COVID-19 Severity",
    "desc":"Learn about Medicare beneficiaries’ varying attitudes toward COVID-19 and the severity of the pandemic.",
    "keywords":"Contagious, Deadly, Severe, Chronic, Coronavirus, Sex, Gender, Age, Income, Race, Ethnicity, Language, English, Dual, Dual eligible, Smoking, Smoker, Tobacco, Immune system, Pandemic, Dually eligible",
    "url":"/covid-data/severity/"
  },
  
  {
    "title":"Financial Assets",
    "desc":"Explore differences in Medicare beneficiaries' ownership of various financial assets.",
    "keywords":"Insurance, Coverage, Fee-for-service, Fee for service, Medicare Advantage, MA, Chronic, Sex, Gender, Age, Language, English, Income, Race, Ethnicity, Dual eligible, Dual, Dually eligible, Geography, Urban, Rural, Region, Metropolitan, Health status, Disability, Home, House, Bank, Retirement, Savings, Social Security, Supplemental Security Income, SSI, Pension, Financial security, Cost, Costs, Money, Finance, Finances",
    "url":"/financial-well-being/assets/"
  },
  {
    "title":"Transportation",
    "desc":"Learn how Medicare beneficiaries' health impacts their daily travel activities.",
    "keywords":"Insurance, Coverage, Fee-for-service, Fee for service, Medicare Advantage, MA, Chronic, Sex, Gender, Age, Language, English, Income, Race, Ethnicity, Dual eligible, Dual, Dually eligible, Geography, Urban, Rural, Region, Metropolitan, Health status, Disability, Drive, Driving, Travel, Transit, Mobility, Ride, Rides, Taxi, Access, Access to care",
    "url":"/financial-well-being/transportation/"
  },
  {
    "title":"Food Insecurity",
    "desc":"Examine how access to sufficient food varies across the Medicare population.",
    "keywords":"Insurance, Coverage, Fee-for-service, Fee for service, Medicare Advantage, MA, Chronic, Sex, Gender, Age, Language, English, Income, Race, Ethnicity, Dual eligible, Dual, Dually eligible, Geography, Urban, Rural, Region, Metropolitan, Health status, Disability, Financial security, Cost, Costs, Money, Finance, Finances, Behavior, Supplies, Needs, Necessities, Eat, Ate, Meals, Afford, Hunger, Hungry, Nutrition, Access, Access to care",
    "url":"/financial-well-being/food/"
  },
  {
    "title":"Internet Access and Use",
    "desc":"Investigate differences in Medicare beneficiaries' access to and use of the internet.",
    "keywords":"Insurance, Coverage, Fee-for-service, Fee for service, Medicare Advantage, MA, Chronic, Sex, Gender, Age, Language, English, Income, Race, Ethnicity, Dual eligible, Dual, Dually eligible, Geography, Urban, Rural, Region, Metropolitan, Health status, Disability, Telehealth, Virtual, Digital, Internet, Information, Web, Online, Access, Access to care",
    "url":"/financial-well-being/internet/"
  },
    
  {
    "title":"Insurance Coverage",
    "desc":"Explore differences in health insurance coverage across Medicare beneficiaries by year.",
    "keywords":"Insurance, Coverage, Private, Employer, Supplemental, Fee-for-service, Fee for service, Medicare Advantage, Part A, Part B, Sex, Gender, Age, Income, Race, Ethnicity, Education",
    "url":"/puf-data/insurance/"  
  },
  {
    "title":"Health Status and Conditions",
    "desc":"Examine differences in Medicare beneficiaries’ health status and the prevalence of health conditions by year.",
    "keywords":"Vision, Wellness, Mental health, Behavioral health, Cholesterol, Hypertension, Arthritis, Hearing, Diabetes, Heart disease, Depression, Cancer, Pulmonary disease, Osteoporosis, Stroke, Alzheimer's, Dementia, Sensory impairment, Sex, Gender, Age, Income, Race, Ethnicity, Education, Chronic",
    "url":"/puf-data/health/"  
  },
  {
    "title":"Satisfaction with and Access to Care",
    "desc":"Learn more about Medicare beneficiaries’ satisfaction with and access to care by year.",
    "keywords":"Provider, Doctor, Medical care, Health care, Appointment, Access, Access to care, Availability, Financial security, Experiences with care, Cost, Sex, Gender, Age, Income, Race, Ethnicity, Education, Costs",
    "url":"/puf-data/satisfaction/"  
  }
  
]
